<?php
error_reporting(1);
ini_set('display_errors', 1);
include("dbconfig.php");
session_start();
$column = array("id", "name", "email", "phone_number", "lead_source", "ip_address","platform_type","project_info_id","created_at","TeamMemeberAccessId");
$sess_id= intval($_SESSION['proj_info_id']);
$role_type= intval($_SESSION['role_type']);
$project_team_id= intval($_SESSION['proj_team_id']);
$query='';
//superadmin
if($role_type==1){
/*$query = "SELECT * FROM leads WHERE lead_hidden_status=0";
*/
$query = "SELECT leads.*,lead_status_info.lead_status_name FROM leads
left join lead_status_info on lead_status_info.id=leads.lead_status
WHERE leads.lead_hidden_status=0";
    
}
//teammember

else if($role_type==2)
{
       $member_id=$_POST['leadmemberid'];
    if($member_id!=0 && $member_id!=null){
 
     /*   $query = "SELECT leads.*,lead_status_info.lead_status_name FROM leads
left join lead_status_info on lead_status_info.id=leads.lead_status
 WHERE leads.lead_hidden_status=0 and  leads.TeamMemeberAccessId=".$member_id." and leads.project_info_id = ".$sess_id;
    */
    
    $data=mysqli_query($conn,"CALL `fetchleads`(".$member_id.", ".$sess_id.", @p2,'', '')");
    $res=mysqli_query($conn,"select @p2");
    $datares=mysqli_fetch_assoc($res);
        $query=$datares['@p2'];
    }
    else
    {
   /* $query = "SELECT * FROM leads WHERE lead_hidden_status=0 and project_info_id = ".$sess_id;
   */ 
 /*    $query = "SELECT leads.*,lead_status_info.lead_status_name FROM leads
left join lead_status_info on lead_status_info.id=leads.lead_status where leads.lead_hidden_status=0 and leads.project_info_id = ".$sess_id;
 */    $data=mysqli_query($conn,"CALL `fetchleads`('', ".$sess_id.", @p2,'', '')");
    $res=mysqli_query($conn,"select @p2");
    $datares=mysqli_fetch_assoc($res);
        $query=$datares['@p2'];
        
    }
     
        
    }
else
{
    /* $query = "SELECT leads.*,lead_status_info.lead_status_name FROM leads
left join lead_status_info on lead_status_info.id=leads.lead_status WHERE leads.lead_hidden_status=0 and leads.TeamMemeberAccessId=".$project_team_id." and leads.project_info_id = ".$sess_id;
*/
     $data=mysqli_query($conn,"CALL `fetchleads`(".$project_team_id.", ".$sess_id.", @p2,'', '')");
    $res=mysqli_query($conn,"select @p2");
    $datares=mysqli_fetch_assoc($res);
        $query=$datares['@p2'];
    
}


if(isset($_POST["leadcheckid"]) && $_POST["leadcheckid"]!='')
{
	$query .= '
	 AND  leads.lead_status='.$_POST["leadcheckid"]; 
	
}


if(isset($_POST["search"]["value"]))
{
	$query .= '
	 AND (  
      leads.id LIKE "%'.$_POST["search"]["value"].'%" 
	OR leads.name LIKE "%'.$_POST["search"]["value"].'%" 
	OR leads.email LIKE "%'.$_POST["search"]["value"].'%" 
	OR leads.phone_number LIKE "%'.$_POST["search"]["value"].'%" 
	OR leads.lead_source LIKE "%'.$_POST["search"]["value"].'%" 
	OR leads.ip_address LIKE "%'.$_POST["search"]["value"].'%" 
	OR leads.platform_type LIKE "%'.$_POST["search"]["value"].'%" 
		OR lead_status_info.lead_status_name LIKE "%'.$_POST["search"]["value"].'%" 
	OR leads.project_info_id LIKE "%'.$_POST["search"]["value"].'%" 

	OR leads.created_at LIKE "%'.$_POST["search"]["value"].'%" ) 
	';
}

if(isset($_POST['order']))
{
	$query .= ' ORDER BY leads.'.$column[$_POST['order']['0']['column']].' '.$_POST['order']['0']['dir'].' ';
}
else
{
	$query .= ' ORDER BY leads.id DESC ';
}



$query1 = '';

if($_POST['length'] != -1)
{
	$query1 = ' LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
}



/*$statement = $conn->prepare($query);



$statement->execute();*/
/*$result=mysqli_query($conn, $query);*/
 
//echo $query;die; 

	
$statement = $conn->prepare($query);

$statement->execute();

$number_filter_row = $statement->get_result()->num_rows;

$result = $conn->query($query . $query1);

$data = array();



//$result = /*$conn->query($query . $query1);*/
//mysqli_query($conn,$query . $query1);

//$number_filter_row= mysqli_num_rows($result);

/*$number_filter_row = $count;*/

/*echo $count;die;*/





/*$data = array();*/
	foreach($result as $row)
{


$sub_array = array();
	
	
$sub_array["DT_RowId"] = "row_".$row['id'];
$sub_array[] = $row['id'];

	$sub_array[] = $row['name'];

	$sub_array[] = $row['email'];

	$sub_array[] = $row['phone_number'];

	$sub_array[] = $row['lead_source'];

	$sub_array[] = $row['ip_address'];

	$sub_array[] = $row['platform_type'];

	$sub_array[] = $row['project_info_id'];


if($row['created_at']==='0000-00-00 00:00:00'){
	 $sub_array[] = '-';
}
else
{
    $sub_array[] = date('Y-m-d',strtotime($row['created_at']));
}

$lead_rel_status_text='';


if($row['lead_relevent']==1)
{
    $lead_rel_status_text="Relevent";
}
if($row['lead_relevent']==0)
{
   $lead_rel_status_text="Non Relevent"; 
}

if($row['lead_relevent']==2)
{
    $lead_rel_status_text="Status";
}

/*	$sub_array[] = "<button type='button' onclick='leadreleventstatus(".$row['id'].")'>".$lead_rel_status_text."</button>";*/
$lead_status_text='';
if($row['lead_status']==0)
{
    $lead_status_text="Raw";
}
if($row['lead_status']==1)
{
   $lead_status_text="Cold"; 
}
if($row['lead_status']==2)
{
  $lead_status_text="Warm";  
}
if($row['lead_status']==3)
{
  $lead_status_text="Hot";  
}

if($row['lead_status']==4)
{
  $lead_status_text="Non-relevent";  
}

	$sub_array[] = "<button type='button' onclick='leadstatus(".$row['id'].")'>".$lead_status_text."</button>";

if(intval($row['TeamMemeberAccessId'])==0){
    
    if(intval($_SESSION['role_type'])!=3){
    
	$sub_array[] = "<div style='display:flex;'>
	<i class='fa fa-pencil' id='row_".$row['id']."' onclick='editrow(".$row['id'].")'></i>&nbsp;&nbsp; 
	<i class='fa fa-eye' aria-hidden='true' id='row_".$row['id']."' onclick='hiderow(".$row['id'].")'></i>
	<button type='button'
	onclick='teammemberaccess(".$row['id'].")'
	class='btn theme-btn pull-right' data-toggle='modal' data-target='#add_lead_member_access_modal' style='margin-bottom: 10px;margin-right: 10px;color: #fff!important;
    background-color: #1893e6;margin-left:10px;width:200px;
    border-color: #158bda;'>Member Access <i class='fa fa-plus-circle' id='row_".$row['id']."'></i>
    </button><button type='button' style='margin-bottom: 0px;margin-right: 10px;color: #fff!important;
    background-color: #1893e6;margin-left:10px;width:150px;
    border-color: #158bda;' class='btn theme-btn pull-right' onclick='event.preventDefault();leadfollowup(".$row['id'].")'>
	Lead Followup</button></div>";
    }
    else{
        $sub_array[] = "<div style='display:flex;'>
	<i class='fa fa-eye' aria-hidden='true' id='row_".$row['id']."' onclick='hiderow(".$row['id'].")'></i>
	<button type='button' style='margin-bottom: 0px;margin-right: 10px;color: #fff!important;
    background-color: #1893e6;margin-left:10px;width:150px;
    border-color: #158bda;' class='btn theme-btn pull-right' onclick='event.preventDefault();leadfollowup(".$row['id'].")'>
	Lead Followup</button></div>";
        
    }
}
else
{
    if(intval($_SESSION['role_type'])!=3){
    
    	$sub_array[] = "<div style='display:flex;'>
	<i class='fa fa-pencil' id='row_".$row['id']."' onclick='editrow(".$row['id'].")'></i>&nbsp;&nbsp;

	<i class='fa fa-eye' aria-hidden='true' id='row_".$row['id']."'  onclick='hiderow(".$row['id'].")'></i>
	<button type='button'
	onclick='teammemberaccess(".$row['id'].")'
	class='btn theme-btn pull-right' data-toggle='modal' data-target='#add_lead_member_access_modal' style='margin-bottom: 10px;margin-right: 10px;color: #fff!important;
    background-color: #93959f;margin-left:10px;width:200px;
    border-color: #93959f;'>Member Assigned <i class='fa fa-plus-circle' id='row_".$row['id']."'></i>
    </button><button type='button' style='margin-bottom: 10px;margin-right: 10px;color: #fff!important;
    background-color: #1893e6;margin-left:10px;width:150px;
    border-color: #158bda;' class='btn theme-btn pull-right' onclick='event.preventDefault();leadfollowup(".$row['id'].")'>
	Lead Followup</button></div>";
    }
    else
    {
        	$sub_array[] = "<div style='display:flex;'>
	<i class='fa fa-eye' aria-hidden='true' id='row_".$row['id']."' onclick='hiderow(".$row['id'].")'></i>&nbsp;&nbsp;
	<button type='button' style='margin-bottom: 0px;margin-right: 10px;color: #fff!important;
    background-color: #1893e6;margin-left:10px;width:150px;
    border-color: #158bda;' class='btn theme-btn pull-right' onclick='event.preventDefault();leadfollowup(".$row['id'].")'>
	Lead Followup</button></div>";
    }
	
	
}

 
 	$sub_array[] = $row['lead_status_name'];


	$data[] = $sub_array;
}






function count_all_data($conn)
{
	$sess_id1= intval($_SESSION['proj_info_id']);
	/*$query = "SELECT * FROM leads WHERE project_info_id = ".$sess_id;
    $result=mysqli_query($conn, $query);
	$count= mysqli_num_rows($result);
	return $count;*/

$role_type= intval($_SESSION['role_type']);

$query2='';
if($role_type==1){
$query2 = "SELECT * FROM leads WHERE lead_hidden_status=0";
}
else if($role_type==2)
{
    $query2 = "SELECT * FROM leads WHERE lead_hidden_status=0 and project_info_id = ".$sess_id1;
}
else
{
     $query2 = "SELECT * FROM leads WHERE lead_hidden_status=0 and project_info_id = ".$sess_id1;
}


/*	$query2 = "SELECT * FROM leads WHERE lead_hidden_status=0 and project_info_id = ".$sess_id1;
*/

	$statement2 = $conn->prepare($query2);

	$statement2->execute();

/*print_r($statement2->get_result());
die;*/

	return $statement2->get_result()->num_rows;
}

$output = array(
	"draw"		=>	intval($_POST["draw"]),
	"recordsTotal"	=>	intval(count_all_data($conn)),
	"recordsFiltered"	=>	intval($number_filter_row),
	"data"		=>	$data
);

echo json_encode($output);

?>