<?php
session_start();
require 'dbconfig.php';
if(!isset($_SESSION['proj_team_id']))
{
  header("location: index.php");
}
$sql = "SELECT id, project_name,project_image_url from project_information where id=".$_SESSION['proj_info_id']." order by id desc";

$projectresult = mysqli_query($conn,$sql);

if ($projectresult->num_rows > 0) 
{
  while($row = $projectresult->fetch_assoc())
  {
      
    $_SESSION['image_url']= $row["project_image_url"];
    $_SESSION['project_name']= $row["project_name"];
  }
}

$sql = "SELECT id, name from project_team where 1 and project_id=".$_SESSION['proj_info_id']." and role_type=3 order by id desc";
$projectteamresult = mysqli_query($conn,$sql);
$sql1 = "SELECT id, lead_status_name from lead_status_info where 1 order by id desc";
$projectstatusresult = mysqli_query($conn,$sql1);
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Lead Management</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.css">
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
</head>
<?php include('header.php');?>
<style>
  body{
    padding: 0px !important;
  }
    .dropdown-check-list {
  display: inline-block;
}
.dropdown-check-list .anchor {
  position: relative;
  cursor: pointer;
  display: inline-block;
  padding: 5px 40px 5px 10px;
  border: 1px solid #ccc;
     /* margin-top: 10px;*/
    background: #fff;
    border-radius: 5px;
    color: #495057;
}
.dropdown-check-list .anchor:after {
  position: absolute;
  content: "";
  border-left: 2px solid black;
  border-top: 2px solid black;
  padding: 5px;
  right: 10px;
  top: 20%;
  -moz-transform: rotate(-135deg);
  -ms-transform: rotate(-135deg);
  -o-transform: rotate(-135deg);
  -webkit-transform: rotate(-135deg);
  transform: rotate(-135deg);
}
.dropdown-check-list .anchor:active:after {
  right: 8px;
  top: 21%;
}
.dropdown-check-list ul.items {
  padding: 2px;
  display: none;
  margin: 0;
  border: 1px solid #ccc;
  border-top: none;
  position:absolute;
  background:#ffffff;
  z-index:100;
  width:150px;
}
.dropdown-check-list ul.items li {
  list-style: none;
}


 .dropdown-check-list1 {
  display: inline-block;
}
.dropdown-check-list1 .anchor {
  position: relative;
  cursor: pointer;
  display: inline-block;
  padding: 5px 40px 5px 10px;
  border: 1px solid #ccc;
     /* margin-top: 10px;*/
    background: #fff;
    border-radius: 5px;
    color: #495057;
}
.dropdown-check-list1 .anchor:after {
  position: absolute;
  content: "";
  border-left: 2px solid black;
  border-top: 2px solid black;
  padding: 5px;
  right: 10px;
  top: 20%;
  -moz-transform: rotate(-135deg);
  -ms-transform: rotate(-135deg);
  -o-transform: rotate(-135deg);
  -webkit-transform: rotate(-135deg);
  transform: rotate(-135deg);
}
.dropdown-check-list1 .anchor:active:after {
  right: 8px;
  top: 21%;
}
.dropdown-check-list1 ul.items {
  padding: 2px;
  display: none;
  margin: 0;
  border: 1px solid #ccc;
  border-top: none;
  position:absolute;
  background:#ffffff;
  z-index:100;
  width:140px;
}
.dropdown-check-list1 ul.items li {
  list-style: none;
}
</style>
<body class="hold-transition skin-blue sidebar-mini" >
<div class="wrapper">
  <?php include('left_side_bar.php');?>
  <div class="content-wrapper" style="height:auto;min-height:0px;"> 
    <!-- Main content -->
<section class="content">
  <div class="card-header" style="margin-bottom:10px">
          <div class="row">
              <div style="margin-left: 10px;">
                <h4><strong>Lead List</strong></h4>
              </div>
          </div>
              <?php if($_SESSION['role_type']==3 || $_SESSION['role_type']==2){?>
          <div class="row">
               <div style="margin-left:8px;">
                <strong>Total:</strong><span style="margin-top: 5px;" id="total_leads_value"></span> 
                <br>
              </div>
          </div>
          <div class="row">
            <div class="col-md-5" style="display:flex;padding:0px;margin-top:8px;">
       
                       <div class="list_view" style="display:flex;">
             
              <div style="margin-left:8px;">
                <strong>Raw:</strong><span style="margin-top: 5px;" id="raw_leads_value"></span> 
                <br>
              </div>
              <div style="margin-left:8px;">
               <strong>Warm:</strong><span style="margin-top: 5px;" id="warm_leads_value"></span>
              <br>
              </div>
              <div style="margin-left:8px;">
               <strong>Cold:</strong><span style="margin-top: 5px;" id="cold_leads_value"></span> 
               <br>
               </div>
 
              <div style="margin-left:8px;">
               <strong>Hot:</strong><span style="margin-top: 5px;" id="hot_leads_value"></span> 
              <br>
              </div>
               
                <div style="margin-left:8px;">
               <strong>Non-Relevent:</strong><span style="margin-top: 5px;" id="non_relevent_leads_value"></span> 
              <br>
              </div>
         </div>
           
           <?php }?>
      </div>
            
            <div class="col-md-5" style="display:flex;justify-content:space-evenly">
                
                <div>
                     <?php if($_SESSION['role_type']==2){ 
?>
 <input type="hidden" value="" id="leadmemberid2">
  <select id="leadmemberid" class="form-control" >
        <option  value=0 >Selelct all</option>
        <?php if ($projectteamresult->num_rows > 0) {
  // output data of each row
  while($row = $projectteamresult->fetch_assoc()) {?>
 
        <option  value=<?php echo  $row['id'];?> ><?php echo  $row['name'];?></option>
       
        <?php }}?>
    </select>
 <?php }?>
                    </div>
                
                
                <div id="list1" class="dropdown-check-list" tabindex="100">
        <span class="anchor">Column</span>
        <ul id="items" class="items">
            <li><input type="checkbox" name="list"  data-target ="2" value="Email" checked  /> Email </li>
            <li><input type="checkbox" name="list"  data-target ="5" value="Ip Address" checked /> Ip Address</li>
            <li><input type="checkbox" name="list" data-target ="6" value="Plateform Type" checked /> Plateform Type </li>
            <li><input type="checkbox" name="list" data-target ="7" value="Project Info Id" checked /> Project Info Id </li>
          
        </ul>
    </div>
    
     
          <div>
        <input type="hidden" id="lead_status_check_id" value="">
       <select id="items2" class="form-control" >
        <option  value='' >Selelct all</option>
        <?php if ($projectstatusresult->num_rows > 0) {
  // output data of each row
  while($row = $projectstatusresult->fetch_assoc()) {?>
 
        <option  value=<?php echo  $row['id'];?> ><?php echo  $row['lead_status_name'];?></option>
       
        <?php }}?>
    </select>
    </div>
    
                
              </div>
            <div class="col-md-2">

  <button type="button" class="btn theme-btn pull-right " data-toggle="modal" data-target="#add_tag_list_modal" style="margin-bottom: 10px;margin-right: 10px;color: #fff!important;
    background-color: #1893e6;
    border-color: #158bda;">New Lead <i class="fa fa-plus-circle"></i>
    </button>


<div class="add_tag_list_modal">
    <div class="modal fade" id="lead_edit_modal" role="dialog">
      <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content" style="width:680px">
          <div class="modal-header">
            <h4 class="modal-title">Edit Lead Details</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            
          </div>
          <div class="modal-body" >
            <div class="user-info-area" id="lead_edit_form_modal_body">
              <form enctype="multipart/form-data" method="post" class="form-inline" id="lead_edit_form">
             
<div class="form-group" style="margin-bottom:10px">
    
            <input type="hidden" value="" name="lead_edit_lead_id" id="lead_edit_lead_id">      
             
             <div style="displlay:block">
              <label class="personal-info-label" style="margin-right:5px;width:150px;"><strong>Name:-</strong></label>
             <input type="name" name="name" id="edit_name"/></div>
             <div style="display:block">
             <label class="personal-info-label" style="margin-right:5px;width:150px;"><strong>Email:-</strong></label>
             <input type="email" name="email" id="edit_email"/></div>
             <div style="display:block">
             <label class="personal-info-label" style="margin-right:5px;width:150px;"><strong>Phone:-</strong></label>
             <input type="text" name="phone" id="edit_phone"/>
</div>
                <hr/>
              </form>





            </div>
          </div> 


</div>

          <div class="modal-footer">
               <button type="button" class="btn btn-danger" data-dismiss="modal" >Cancel</button>
       
            <button type="button" class="btn theme-btn" id="add-company-btn" onClick="addNewLeadEdit();" style="color: #fff!important;background-color: #1893e6;border-color: #158bda;">Create</button>

              </div>
        </div>
      </div>
    </div>
  </div>




    
<div class="add_tag_list_modal">
    <div class="modal fade" id="lead_status_modal" role="dialog">
      <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content" style="width:720px">
          <div class="modal-header">
            <h4 class="modal-title">Lead Status Details</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            
          </div>
          <div class="modal-body" >
            <div class="user-info-area" id="lead_follow_form_modal_body">
              <form enctype="multipart/form-data" method="post" class="form-inline" id="lead_status_form">
             
<div class="form-group" style="margin-bottom:10px">
    
            <input type="hidden" value="" name="lead_status_lead_id" id="lead_status_lead_id">      
             
              <label class="personal-info-label" style="margin-right:5px;width:150px;"><strong>Lead Follow Up Message:-</strong></label>
             <textarea  required name="folowupmessage" id="folowupmessage"></textarea>
             
                <label class="personal-info-label" style="margin-right:5px;width:150px;"><strong>Lead Status:-</strong></label>
         <select id="lead_status" name="lead_status" class="form-control">
          <option value="">All Lead</option>
          <option value="0">Raw Lead</option>
          <option value="1">Cold Lead</option>
         <option value="2">Warm Lead</option>
          <option value="3">Hot Lead</option>
           <option value="4">Non-Relevent Lead</option>
         </select>

                <hr/>
              </form>





            </div>
          </div> 


</div>

          <div class="modal-footer">
               <button type="button" class="btn btn-danger" data-dismiss="modal" >Cancel</button>
       
            <button type="button" class="btn theme-btn" id="add-company-btn" onClick="addNewLeadStatus();" style="color: #fff!important;background-color: #1893e6;border-color: #158bda;">Create</button>

              </div>
        </div>
      </div>
    </div>
  </div>




<div class="add_tag_list_modal">
    <div class="modal fade" id="lead_relevent_status_modal" role="dialog">
      <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content" style="width:680px">
          <div class="modal-header">
            <h4 class="modal-title">Lead Relevent Status Details</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            
          </div>
          <div class="modal-body" >
            <div class="user-info-area" id="lead_follow_form_modal_body">
              <form enctype="multipart/form-data" method="post" class="form-inline" id="lead_rel_status_form">
             
<div class="form-group" style="margin-bottom:10px">
    
            <input type="hidden" value="" name="lead_rel_status_lead_id" id="lead_rel_status_lead_id">      
             
             
                <label class="personal-info-label" style="margin-right:5px;width:150px;"><strong>Lead Status:-</strong></label>
         <select id="lead_rel_status" name="lead_rel_status" class="form-control">
         <option value="2">Please Select Lead Relevent Status</option>
          <option value="0">Non Relevent</option>
          <option value="1">Relevent</option>
           
        
         </select>

                <hr/>
              </form>





            </div>
          </div> 


</div>

          <div class="modal-footer">
               <button type="button" class="btn btn-danger" data-dismiss="modal" >Cancel</button>
       
            <button type="button" class="btn theme-btn" id="add-company-btn" onClick="addNewLeadRelStatus();" style="color: #fff!important;background-color: #1893e6;border-color: #158bda;">Create</button>

              </div>
        </div>
      </div>
    </div>
  </div>




<div class="add_tag_list_modal">
    <div class="modal fade" id="lead_follow_modal" role="dialog">
      <div class="modal-dialog" style="max-width: 530px!important;">
        <!-- Modal content-->
        <div class="modal-content"  >
          <div class="modal-header">
            <h4 class="modal-title">Lead FollowUp Details</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            
          </div>
          <div class="modal-body" >
            <div class="user-info-area" id="lead_follow_form_modal_body">
              <form enctype="multipart/form-data" method="post" class="form-inline" id="lead_follow_form" style="margin:0px">
             
<div class="form-group">
            <input type="hidden" value="" name="lead_followup_lead_id" id="lead_followup_lead_id">      
           <!-- <label class="personal-info-label" style="margin-right:5px;width:150px;"><strong>Lead Followup Message:-</strong></label>
       -->    <!--<textarea  required name="folowupmessage" id="folowupmessage"></textarea>-->
              <!--  <hr/>-->
              </form>
       </div>
          </div> 


  <div id="view_lead_follow_history" >
            <div class="user-info-area">
 <div>
              <table id="example2" class="table table-bordered table-striped table-responsive" style="overflow:unset;border:unset;width:unset!important">
                <thead>
                <tr>
                                    <th>Id</th>
                  <th>Lead Id</th>
                  <th>Team Id</th>
                  <th>Created By</th>
                  <th>Message</th>
                  <th>Created At</th>
                  <th>Action</th>
                
                </tr>
                </thead>
              </table>
            </div>
  </div>  </div>
</div>

          <div class="modal-footer">
              <!-- <button type="button" class="btn btn-danger" data-dismiss="modal" >Cancel</button>-->
       
          <!--  <button type="button" class="btn theme-btn" id="add-company-btn" onClick="addNewLeadFollowUp();" style="color: #fff!important;background-color: #1893e6;border-color: #158bda;">Create</button>
-->
            <!-- <button type="button" class="btn theme-btn addNewLeadFollowUpHistory"   style="color: #fff!important;background-color: #1893e6;border-color: #158bda;">View</button>-->
              </div>
        </div>
      </div>
    </div>
  </div>







<div class="add_tag_list_modal">
    <div class="modal fade" id="add_lead_member_access_modal" role="dialog">
      <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title">Lead Member Access</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            
          </div>
          <div class="modal-body">
            <div class="user-info-area">
              <form enctype="multipart/form-data" method="post" class="form-inline" id="leadmemberaccessform">
             
<div class="form-group" style="margin-bottom:10px">
    
            <input type="hidden" value="" name="member_access_lead_id" id="member_access_lead_id">      
             
           
             <div class="form-group" style="margin-bottom:10px;">
                    <label class="personal-info-label" style="margin-right:5px;width:150px;"><strong>Team Member:-</strong></label>

<?php 
/*$member_access_id='';
                      $sql1 = "SELECT project_team.id from project_team 
                      left join leads on leads.TeamMemeberAccessId=project_team.id
                      where project_team.role_type=3 and project_team.project_id=".$_SESSION['proj_info_id']." order by project_team.id desc";
 
$result12 = mysqli_query($conn,$sql1);
if ($result12->num_rows > 0) 
{
    while($rowaccess = $result12->fetch_assoc()) {
        $member_access_id=$rowaccess['id'];
        
    }
    
}*/

?>
                    <select name="project_team_member" class="form-control" id="project_team_member">
                    <option value="0">not assign</option>
                     <?php 

                     $sql = "SELECT id,name from project_team where role_type=3 and project_id=".$_SESSION['proj_info_id']." order by id desc";
 
$result = mysqli_query($conn,$sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {?>
                      <option 
                     <?php  //if(intval($member_access_id)==intval($row['id'])){echo 'selected';}?>
                      
                      value="<?php echo $row['id'];?>"><?php echo $row['name'];?></option>
                    <?php }}?>
                    </select>
                  </div>

                <hr/>
              </form>
            </div>
          </div>
          <div class="modal-footer">
               <button type="button" class="btn btn-danger" data-dismiss="modal" >Cancel</button>
       
            <button type="button" class="btn theme-btn" id="add-company-btn" onClick="addNewLeadMemeberAccess();" style="color: #fff!important;background-color: #1893e6;border-color: #158bda;">Create</button>
              </div>
        </div>
      </div>
    </div>
  </div>
    <div class="add_tag_list_modal">
    <div class="modal fade" id="add_tag_list_modal" role="dialog">
      <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title"> New Lead</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            
          </div>
          <div class="modal-body">
            <div class="user-info-area">
              <form enctype="multipart/form-data" method="post" class="form-inline" id="leadform">
             
<div class="form-group" style="margin-bottom:10px">
    
    <input type="hidden" name="teammemberid" value="<?php echo $_SESSION['proj_team_id']; ?>">
    <input type="hidden" name="userrole" class="form-control" value="<?php echo  $_SESSION['role_type']; ?>"/> 
                    <input type="hidden" name="ipAddress" class="form-control" id="ipAddress"/>   
                    <input type="hidden" name="platformType" class="form-control" id="platformType"/>          
                    <label class="personal-info-label" style="margin-right:5px;width:150px;"><strong>Name:-</strong></label>
                    <input type="text" name="name" class="form-control" id="tag_name"/>
                    </div>
             
             <div class="form-group" style="margin-bottom:10px">
                    <label class="personal-info-label" style="margin-right:5px;width:150px;"><strong>Email:-</strong></label>
                    <input type="text" name="email" class="form-control" id="email"/>
             </div>
             <div class="form-group" style="margin-bottom:10px">
                    <label class="personal-info-label" style="margin-right:5px;width:150px;"><strong>Phone Number:-</strong></label>
                    <input type="text" name="phone_number" class="form-control" id="phone_number"/>
             </div>
             <div class="form-group" style="margin-bottom:10px;display: none;">
                    <label class="personal-info-label" style="margin-right:5px;width:150px;"><strong>Project Type:-</strong></label>

                    <select name="project_type" class="form-control" id="project_type">
                     <?php 
                     $sql = "SELECT id, project_name,project_image_url from project_information where id=".$_SESSION['proj_info_id']." order by id desc";
 
$result = mysqli_query($conn,$sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {?>
                      <option value="<?php echo $row['id'];?>"><?php echo $row['project_name'];?></option>
                    <?php }}?>
                    </select>
                  </div>

                   <div class="form-group" style="margin-bottom:10px">
                    <label class="personal-info-label" style="margin-right:5px;width:150px;"><strong>Created At:-</strong></label>
                    <!-- <input type="text" name="phone_number" class="form-control" id="phone_number"/> -->

                    <input type="text" name="created_at_date" id = "datepicker-13">
             </div> 
                 
<div class="form-group" style="margin-bottom:10px;">

               
                    <label class="personal-info-label" style="margin-right:5px;width:150px;"><strong>Lead Source:-</strong></label>
                    <!--<input type="text" name="form_type" class="form-control" id="form_type"/>-->
              
               <select name="form_type" class="form-control" id="form_type">
                   
                      <option value="PPC">PPC</option>
                      <option value="FACEBOOK">Facebook</option>
                      <option value="INSTAGRAM">Instagram</option>
                      <option value="DIRECTCALL">DirectCall</option>
                      <option value="WHATSAPPCHAT">Whatsappchat</option>
                      <option value="IVR">IVR</option>
                      


                  
                    </select>
              
              
                </div>
                
            
                <hr/>
              </form>
            </div>
          </div>
          <div class="modal-footer">
               <button type="button" class="btn btn-danger" data-dismiss="modal" >Cancel</button>
       
            <button type="button" class="btn theme-btn" id="add-company-btn" onClick="addNewLead();" style="color: #fff!important;background-color: #1893e6;border-color: #158bda;">Create</button>
              </div>
        </div>
      </div>
    </div>
  </div>
              <div class="input-group" style="display:none;">
                <div class="input-group-prepend">
                  <span class="input-group-text">Page</span>
                </div>
                <select name="pagelist" id="pagelist" class="form-control"></select>
                <div class="input-group-append">
                  <span class="input-group-text">of&nbsp;<span id="totalpages"></span></span>
                </div>
              </div>
            </div>
          </div>
        </div>

     
            
            <!-- /.box-header -->
            <div>
              <table id="example1" class="table table-bordered table-striped table-responsive" style="overflow:unset;margin-bottom:20px;">
                <thead>
                <tr>
                                    <th>Id</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Phone Number </th>
                  <th>Lead Source</th>
                  <th>Ip Address</th>
                  <th>Platform Type</th>
                   <th>Project Info id</th>
                  <th>Created At</th>
                 <!-- <th>Lead Relevent Status</th>-->
                  <th>Status</th>
                  <th>Action</th>
                  
                   

               
                </tr>
                </thead>
               <!--  <tbody> -->

<?php
/*
if (mysqli_num_rows($result) > 0) {
  // output data of each row
  while($row = mysqli_fetch_assoc($result)) {


  $count=$key+1;
  
        echo'<tr>'; 
        echo'<td>'.$count.'</td>';
        echo'<td>'.$row['name'].'</td>';
        echo'<td>'.$row['email'].'</td>';
        echo'<td>'.$row['phone_number'].'</td>';
        echo'<td>'.$row['form_type'].'</td>';
        echo'<td>'.$row['ip_address'].'</td>';
        echo'<td>'.$row['platform_type'].'</td>';
        echo'<td>'.$row['created_at'].'</td>';
}     

}   
*/   

?>

             <!--  </tbody> -->
               
              </table>
            </div>
            <!-- /.box-body -->
        
      

    </section>





     
    </section>

  </div>
  
 
  
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<!-- jQuery 2.2.3 -->
<!-- <script src="plugins/jQuery/jquery-2.2.3.min.js"></script> -->
<!-- jQuery UI 1.11.4 -->
<!-- <script src="plugins/jQuery/jquery-ui.min.js"></script> -->
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<!-- <script>
  $.widget.bridge('uibutton', $.ui.button);
</script> -->
<!-- Bootstrap 3.3.6 -->
<!-- <script src="bootstrap/js/bootstrap.min.js"></script> -->
<!-- Morris.js charts -->
<!-- <script src="plugins/jQuery/raphael-min.js"></script> -->

<!-- daterangepicker -->
<!-- <script src="plugins/jQuery/moment.min.js"></script> -->

<!-- Bootstrap WYSIHTML5 -->
<!-- <script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script> -->

<!-- AdminLTE App -->
<!-- <script src="dist/js/app.min.js"></script> -->
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<!-- <script src="dist/js/pages/dashboard.js"></script> -->
<!-- AdminLTE for demo purposes -->
<!-- <script src="dist/js/demo.js"></script> -->

<!-- page script -->

<!-- <script src="plugins/jQuery/jquery-2.2.3.min.js"></script> -->
<!-- Bootstrap 3.3.6 -->
<!-- <script src="bootstrap/js/bootstrap.min.js"></script> -->
<!-- DataTables -->
<!-- <script src="plugins/datatables/jquery.dataTables.min.js"></script>
<script src="plugins/datatables/dataTables.bootstrap.min.js"></script> -->

<!-- AdminLTE App -->
<!-- <script src="dist/js/app.min.js"></script -->>
 <script  src="https://code.jquery.com/jquery-3.5.1.js" integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>
    <!-- CSS only -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">   
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>

<link
      href="https://code.jquery.com/ui/1.12.1/themes/ui-lightness/jquery-ui.css"
      rel="stylesheet"
    />

    <!-- ✅ load jQuery ✅ -->


    <!-- ✅ load jquery UI ✅ -->
    <script
      src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"
      integrity="sha512-uto9mlQzrs59VwILcLiRYeLKPPbS/bT71da/OEBYEwcdNUk8jYIy+D176RYoop1Da+f9mvkYrmj5MCLZWEtQuA=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    ></script>
      


    <script src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.22/js/dataTables.bootstrap4.min.js"></script>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.22/css/dataTables.bootstrap4.min.css" />
  



<script src="dist/js/demo.js"></script>

   
<script type="text/javascript" language="javascript">
    var ipAddress="";
  function getIP(json) {
      //document.write("My public IP address is: ", json.ip);
        ipAddress=json.ip;
       /* SendVisitorEntries(ipAddress,platformType);*/
        console.log("PlatformType "+platformType+"IP Address "+ipAddress);
      }


$(document).ready(function(){
  var leadmemberid222;
  
  var platformType="none";

    
    var isMobile = {
        Android: function() {
          return navigator.userAgent.match(/Android/i);
        },
        BlackBerry: function() {
          return navigator.userAgent.match(/BlackBerry/i);
        },
        iOS: function() {
          return navigator.userAgent.match(/iPhone|iPad|iPod/i);
        },
        Opera: function() {
          return navigator.userAgent.match(/Opera Mini/i);
        },
        Windows: function() {
          return navigator.userAgent.match(/IEMobile/i) || navigator.userAgent.match(/WPDesktop/i);
        },
        any: function() {
          return (isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Opera() ||                                         isMobile.Windows());
        }
         };
    if( isMobile.any() )
    {
      
      platformType="mobile";
         
    }
    else{
        
      platformType="Desktop";
          
    }

   
    $("#ipAddress").val(ipAddress);
    $("#platformType").val(platformType);



  

    
  function load_data(start, length)
  {
  
    var dataTable = $('#example1').DataTable({
      "processing" : true,
      "serverSide" : true,
       "bPaginate": true,
        "bFilter": true,
        "bInfo": true,
      "order" : [],
      "retrieve": true,
 
      "ajax" : {
        url:"fetch.php",
        method:"POST",
        data:{start:start, length:length, leadmemberid:$("#leadmemberid2").val() ,status:2, leadcheckid:$("#lead_status_check_id").val()}
      },
      "columnDefs": [
    { "visible": false, "targets": [2,5, 6, 7] }
  ],
      "drawCallback" : function(settings){
        var page_info = dataTable.page.info();
          console.log(page_info);
      $('#totalpages').text(page_info.pages);
        var html = '';
        var start = 0;
        var length = page_info.length;
        for(var count = 1; count <= page_info.pages; count++)
        {
          var page_number = count - 1;
          html += '<option value="'+page_number+'" data-start="'+start+'" data-length="'+length+'">'+count+'</option>';
          start = start + page_info.length;
        }
        $('#pagelist').html(html);
        $('#pagelist').val(page_info.page);
      }
    });
    
   $('ul.items>li>input[type="checkbox"]').on('change', function(e) {
    var col = dataTable.column($(this).attr('data-target'));
    col.visible(!col.visible());
});
   dataTable.ajax.reload();
  }    
  
  

 $('#pagelist').change(function(){
    var start = $('#pagelist').find(':selected').data('start');
    var length = $('#pagelist').find(':selected').data('length');
    load_data(start, length);
    var page_number = parseInt($('#pagelist').val());
    var test_table = $('#example1').dataTable();
    test_table.fnPageChange(page_number);
  });


   $("#leadmemberid").on("change", function() 
 {
      
    var leadmemberid = $("#leadmemberid").val();
     $("#leadmemberid2").val(leadmemberid);  
  leadstatusdetails(leadmemberid); 
  if ($.fn.DataTable.isDataTable("#example1")) {
  $('#example1').DataTable().clear().destroy();
}

  load_data(); 
  
  
});


   $('#items2').on('change', function(e) {
    var col = $(this).val();
  $("#lead_status_check_id").val(col);
    if ($.fn.DataTable.isDataTable("#example1")) {
  $('#example1').DataTable().clear().destroy();
}
  
  load_data();
  
    
    
});


load_data();
 });




$("#example1").parent().css('overflow-x','scroll');


function teammemberaccess(leadid)
{
$("#member_access_lead_id").val(leadid);

}

   function updateinfoedit(){
      var lead_edit_id= $("#lead_edit_lead_id").val();
   $.ajax({
  url:"AjaxLeadEditInfoData.php", 
  data:{"lead_edit_id":lead_edit_id},
  type:'post',
  async: true,
  dataType:'json',
 
  success:function(response){
    console.log(response);
    var status=response['Status'];
   /* alert(response['Message']);*/
  /*  if(status==1){
      location.reload();
    }*/
    
    $("#edit_name").val(response.name);
    $("#edit_email").val(response.email);
    $("#edit_phone").val(response.phone);
    
  },
  error: function(xhr, status, error) {
    var err = eval("(" + xhr.responseText + ")");
    alert(err.Message);
  }
});
}
 
 
 
 

function leadstatusdetails(member_id)
{
 $.ajax({
        url:"fetchleadstatus.php",
         data:{"member_id":member_id},
  type:'post',
 
  dataType:'json',

     success:function(response){
         console.log("data");
    console.log(response);
   var status=response['Status'];
 /*   alert(response['Message']);*/
    if(status==1){
  
  var rawleads=0;
  var hotleads=0;
  var coldleads=0;
  var warmleads=0;
   var nonreleventleads=0;
   var totalleads=0;
  if(rawleads!=null)
  {
      rawleads=response['RawLeads'];  
      totalleads=totalleads+parseInt(rawleads);
  }
  if(hotleads!=null)
  {
       hotleads=response['HotLeads']; 
       totalleads=totalleads+parseInt(hotleads);
  }
    if(coldleads!=null)
  {
       coldleads=response['ColdLeads'];  
       totalleads=totalleads+parseInt(coldleads);
  }
    if(warmleads!=null)
  {
       warmleads=response['WarmLeads'];  
       totalleads=totalleads+parseInt(warmleads);
  }
  
    if(nonreleventleads!=null)
  {
       nonreleventleads=response['NonReleventLeads'];  
       totalleads=totalleads+parseInt(nonreleventleads);
  }
      $("#raw_leads_value").text(rawleads);
       $("#hot_leads_value").text(hotleads);
        $("#cold_leads_value").text(coldleads);
         $("#warm_leads_value").text(warmleads);
         $("#non_relevent_leads_value").text(nonreleventleads);
          $("#total_leads_value").text(totalleads);
      
    }
  },
})   


} 

leadstatusdetails(null);






function load_data1(start, length)
  {
   var lead_id =$("#lead_followup_lead_id").val();
    var dataTable = $('#example2').DataTable({
        
        rowCallback: function(row, data, index) {
        $(row).find('td:eq(2)').css('width', '60px');
           $(row).find('td:eq(2)').css('max-width', '60px');
           $(row).find('td:eq(2)').css('overflow-x', 'scroll');
              $(row).find('td:eq(1)').css('width', '60px');
           $(row).find('td:eq(1)').css('max-width', '60px');
           $(row).find('td:eq(1)').css('overflow-x', 'scroll');
            $(row).find('td:eq(0)').css('width', '60px');
           $(row).find('td:eq(0)').css('max-width', '60px');
             $(row).find('td:eq(3)').css('width', '60px');
           $(row).find('td:eq(3)').css('max-width', '60px');
             $(row).find('td:eq(4)').css('width', '60px');
           $(row).find('td:eq(4)').css('max-width', '60px');
              $(row).find('td:eq(5)').css('width', '60px');
           $(row).find('td:eq(5)').css('max-width', '60px');
               $(row).find('td:eq(6)').css('width', '60px');
           $(row).find('td:eq(6)').css('max-width', '60px');
               $(row).find('td:eq(7)').css('width', '60px');
           $(row).find('td:eq(7)').css('max-width', '60px');
             $(row).find('td:eq(8)').css('width', '60px');
           $(row).find('td:eq(8)').css('max-width', '60px');
           
    },

      "processing" : true,
      "serverSide" : true,
       "bPaginate": false,
        "bFilter": false,
        "bInfo": false,
      "order" : [],
      "retrieve": true,
      "ajax" : {
        url:"fetchleadfollow.php",
        method:"POST",
        data:{start:start, length:length,lead_id:lead_id}
      },
      "columnDefs": [
    { "visible": false, "targets": [1,2] ,"className": 'dt-body-right' }
  ],

      "drawCallback" : function(settings){
        var page_info = dataTable.page.info();

console.log(page_info);

/*page_info.pages= Math.ceil(page_info.recordsTotal/page_info.length);*/
        $('#totalpages').text(page_info.pages);

        var html = '';

        var start = 0;

        var length = page_info.length;


        for(var count = 1; count <= page_info.pages; count++)
        {
          var page_number = count - 1;

          html += '<option value="'+page_number+'" data-start="'+start+'" data-length="'+length+'">'+count+'</option>';

          start = start + page_info.length;
        }

        $('#pagelist').html(html);

        $('#pagelist').val(page_info.page);
      }
    });
    dataTable.ajax.reload();
  }






function leadfollowup(leadid)
{
 /*alert(leadid);*/
$("#lead_follow_modal").modal('show');
$("#lead_followup_lead_id").val(leadid);
   if ($.fn.DataTable.isDataTable("#example2")) {
  $('#example2').DataTable().clear().destroy();
} 
  load_data1();

}


function leadstatus(leadid)
{
 /*alert(leadid);*/
$("#lead_status_modal").modal('show');
$("#lead_status_lead_id").val(leadid);

}


function leadreleventstatus(leadid)
{
 /*alert(leadid);*/
$("#lead_relevent_status_modal").modal('show');
$("#lead_rel_status_lead_id").val(leadid);

}


function editrow(leadid)
{
 /*alert(leadid);*/
$("#lead_edit_modal").modal('show');

$("#lead_edit_lead_id").val(leadid);
updateinfoedit(null);
}




function addNewLeadStatus()
{

  if($("#lead_status").val()=="" && $("#folowupmessage").val()=="")
{
  alert("please select any one field");
  return false;
}

var fd7=document.getElementById('lead_status_form');
  var form_data8 = new FormData(fd7); 
 $.ajax({
        url:"lead_status_info.php",
         data:form_data8,
  type:'post',
  async: true,
  dataType:'json',
  contentType: false,
  cache: false,
  processData: false,
     success:function(response){
    console.log(response);
   var status=response['Status'];
     var lead_status_value=response['lead_status_value'];
     var lead_id=response['lead_id'];
    alert(response['Message']);
    if(status==1){
      /*location.reload();*/
      
      $("#lead_status_modal").modal('hide'); 
var table = $('#example1').DataTable(); table.cell("#row_"+lead_id, 9).data('<button type="button" onclick="leadstatus('+lead_id+')">'+lead_status_value+'</button>').draw();

//var table = $('#example1').DataTable(); table.cell("#row_"+lead_id, 9).html('<button type="button" onclick="leadstatus('+lead_id+')">'+lead_status_value+'</button>').draw();
/*$('#row_'+lead_id+' td').eq(5).html('<button type="button" onclick="leadstatus('+lead_id+')">'+lead_status_value+'</button>');*/

    }
  },
})   


}




function addNewLeadRelStatus()
{

  if($("#lead_rel_status").val()=="")
{
  alert("please select field");
  return false;
}

var fd71=document.getElementById('lead_rel_status_form');
  var form_data81 = new FormData(fd71); 
 $.ajax({
        url:"lead_rel_status_info.php",
         data:form_data81,
  type:'post',
  async: true,
  dataType:'json',
  contentType: false,
  cache: false,
  processData: false,
     success:function(response){
    console.log(response);
   var status=response['Status'];
     var lead_status_value=response['lead_status_value'];
     var lead_id=response['lead_id'];
    alert(response['Message']);
    if(status==1){
      /*location.reload();*/
      
      $("#lead_status_modal").modal('hide'); 
var table = $('#example1').DataTable(); table.cell("#row_"+lead_id, 9).data('<button type="button" onclick="leadstatus('+lead_id+')">'+lead_status_value+'</button>').draw();

//var table = $('#example1').DataTable(); table.cell("#row_"+lead_id, 9).html('<button type="button" onclick="leadstatus('+lead_id+')">'+lead_status_value+'</button>').draw();
/*$('#row_'+lead_id+' td').eq(5).html('<button type="button" onclick="leadstatus('+lead_id+')">'+lead_status_value+'</button>');*/

    }
  },
})   


}


function leadfollowstatus(leadfollowid)
{
   
    $.ajax({
        url:"lead_followup_status.php",
         data:{"leadfollowid":leadfollowid},
  type:'post',
  async: true,
  dataType:'json',
     success:function(response){
    console.log(response);
   var status=response['Status'];
    alert(response['Message']);
    if(status==1){
      location.reload();
    }
  },
})   
 
}

function addNewLeadFollowUp()
{
  $("#lead_follow_form_modal_body").show();
  /*$("#view_lead_follow_history").hide();*/


var fd5=document.getElementById('lead_follow_form');
  var form_data6 = new FormData(fd5); 


if($("#folowupmessage").val()=="")
{
  alert("please fill the follow up message field");
  return false;
}

if($("#folowupmessage").val().length>50)
{
  alert("follow up message length should not be greater than 50");
  return false;
}

 $.ajax({
        url:"lead_followup_info.php",
         data:form_data6,
  type:'post',
  async: true,
  dataType:'json',
  contentType: false,
  cache: false,
  processData: false,
     success:function(response){
    console.log(response);
   var status=response['Status'];
    alert(response['Message']);
    if(status==1){  
        
        $("#folowupmessage").val("");
        $("#lead_follow_modal").modal("hide");
      /*location.reload();*/
    }
  },
})   
}


function addNewLeadMemeberAccess()
{ 
    var fd3=document.getElementById('leadmemberaccessform');
  var form_data2 = new FormData(fd3); 
 $.ajax({
        url:"lead_member_access.php",
         data:form_data2,
  type:'post',
  async: true,
  dataType:'json',
  contentType: false,
  cache: false,
  processData: false,
     success:function(response){
    console.log(response);
    var status=response['Status'];
    alert(response['Message']);
    if(status==1){
        $("#add_lead_member_access_modal").modal('hide');
      
     /* location.reload();*/
    }
  },
})   
}


function hiderow(rowid)
{

  $.ajax({
        url:"hiderow.php",
        method:"POST",
        data:{rowid:rowid},
       success: function(data){
       
        var dataObject = $.parseJSON(data);
        console.log(dataObject);
         if(dataObject==="success"){
        
        $("#row_"+rowid).removeClass('fa fa-eye');
             $("#row_"+rowid).addClass('fa fa-eye-slash');
                /*$(this).closest("tr").hide();*/
             window.location.reload();
              
         }else{
             alert("can't delete the row")
         }
    }
});
}

function addNewLeadEdit()
{
    
    var fd2=document.getElementById('lead_edit_form');
  var form_data = new FormData(fd2); 
  
   if ($('#edit_name').val()== '') {
    alert("Please Enter Name");
  }

/* else if ($('#edit_email').val()== '') {
    alert("Please Enter Email");
  }

 else if ($('#edit_phone').val()== '') {
    alert("Please Enter Phone Number");
  }
*/

  else{
 $.ajax({
  url:"AjaxEditLead.php", 
  data:form_data,
  type:'post',
  async: true,
  dataType:'json',
  contentType: false,
  cache: false,
  processData: false,
  success:function(response){
    console.log(response);
    var status=response['Status'];
    alert(response['Message']);
    if(status==1){
      location.reload();
    }
  },
  error: function(xhr, status, error) {
    var err = eval("(" + xhr.responseText + ")");
    alert(err.Message);
  }
});
}

    
}


 function addNewLead(){ 
var fd2=document.getElementById('leadform');
  var form_data = new FormData(fd2); 
   /*var form_data = new FormData(document.querySelector('form'));  */
   if ($('#name').val()== '') {
    alert("Please Enter Name");
  }

 else if ($('#email').val()== '') {
    alert("Please Enter Email");
  }

 else if ($('#phone_number').val()== '') {
    alert("Please Enter Phone Number");
  }

   else if ($('#project_type').val()== '') {
    alert("Please Select Project Type");
  }

    else if ($('#form_type').val()== '') {
    alert("Please Select Form Type");
  }


  else{

  //form_data.append('file',files[0]);

// form_data.append("file", document.getElementById('file').files[0]);
 // alert('statrttt');
 $.ajax({
  url:"AjaxCreateLead.php", 
  data:form_data,
  type:'post',
  async: true,
  dataType:'json',
  contentType: false,
  cache: false,
  processData: false,
  success:function(response){
    console.log(response);
    var status=response['Status'];
    alert(response['Message']);
    if(status==1){
      location.reload();
    }
  },
  error: function(xhr, status, error) {
    var err = eval("(" + xhr.responseText + ")");
    alert(err.Message);
  }
});
}
}
$(function() {


  
  $(".menu").on("click", function() {
    $(".menu > i").toggleClass("fa-bars fa-close", 300);
    $(".sidebar-menu").toggleClass("show-sidebar", 5000);
    $("body").toggleClass("push-body", 5000);
  });
  

});
 

 
$(function() {

  
  
    $(".addNewLeadFollowUpHistory").on("click", function(e) {
  e.preventDefault();
  
     if ($.fn.DataTable.isDataTable("#example2")) {
  $('#example2').DataTable().clear().destroy();
} 
 $("#lead_follow_form_modal_body").hide();
  $("#view_lead_follow_history").show();     
     load_data1();
      
});
});

$(function() {
$("#lead_follow_modal").on("hidden.bs.modal", function(){
   /*window.location.reload();*/
     if ($.fn.DataTable.isDataTable("#example2")) {
  $('#example2').DataTable().clear().destroy();
} 
   load_data1();
   /*$("#folowupmessage").val('');*/
   $("#example2>tbody").html("");
  
});

});

</script>
 <script type="application/javascript" src="https://api.ipify.org?format=jsonp&callback=getIP"></script>
  <script>
$(function() {
            $( "#datepicker-13" ).datepicker({ dateFormat: 'yy-mm-dd' });
         });

</script> 

  <script>
var checkList = document.getElementById('list1');
var items = document.getElementById('items');
checkList.getElementsByClassName('anchor')[0].onclick = function(evt) {
  if (items.classList.contains('visible')) {
    items.classList.remove('visible');
    items.style.display = "none";
  } else {
    items.classList.add('visible');
    items.style.display = "block";
  }

}

items.onblur = function(evt) {
  items.classList.remove('visible');
}






</script>
</body>
</html>
